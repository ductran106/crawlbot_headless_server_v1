# Điều hướng và tìm kiếm nhóm
# src/browser/navigation.py
import re
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

from ..utils.logger import log, logging
from ..utils.config import DEFAULT_GROUP_NAME
from ..utils.browser_errors import is_browser_dead_error
from ..utils.decorators import retry_on_webdriver_error
from ..utils.error_logger import log_error
from ..utils.fail_artifacts import FailArtifactMixin
from ..utils.signals import is_terminating
from ..utils.status_codes import (
    ALREADY_LOGGED_IN,
    GROUP_OPENED_AT_NAVIGATION,
    GROUP_OPENED_UNVERIFIED,
    GROUP_SEARCH_EMPTY,
    LOGIN_STATE_UNKNOWN,
    QR_VISIBLE,
    RECONNECT_HEADER_UNVERIFIED,
)

class ZaloNavigator(FailArtifactMixin):
    """Quản lý điều hướng trong Zalo Web"""
    
    def __init__(self, driver):
        """Khởi tạo ZaloNavigator với WebDriver đã được khởi tạo"""
        self.driver = driver

    def _collect_conv_item_labels(self, conv_items, limit=5):
        labels = []
        for item in conv_items[:limit]:
            try:
                text = (item.text or "").strip()
            except Exception:
                text = ""
            if text:
                labels.append(text)
        return labels

    def _should_quiet_shutdown_browser_error(self, error):
        return is_terminating() and is_browser_dead_error(error)

    def _normalize_group_text(self, text):
        text = (text or "").strip().lower()
        text = re.sub(r"[^\w\s]+", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _strip_noise_tokens(self, text):
        normalized = self._normalize_group_text(text)
        if not normalized:
            return ""
        tokens = []
        for tok in normalized.split():
            if tok.isdigit():
                continue
            if re.fullmatch(r"\d+[a-z]+", tok) or re.fullmatch(r"[a-z]+\d+", tok):
                continue
            if len(tok) == 1 and tok.isalnum():
                continue
            tokens.append(tok)
        return " ".join(tokens).strip()

    def _target_tokens(self, group_name):
        normalized = self._normalize_group_text(group_name)
        return [p for p in normalized.split() if p]

    def _matches_target_group(self, candidate_text, group_name):
        candidate = self._normalize_group_text(candidate_text)
        target = self._normalize_group_text(group_name)
        if not candidate or not target:
            return False
        if target in candidate:
            return True

        candidate_stripped = self._strip_noise_tokens(candidate_text)
        target_stripped = self._strip_noise_tokens(group_name)
        if candidate_stripped and target_stripped:
            if target_stripped in candidate_stripped or candidate_stripped in target_stripped:
                return True

        parts = self._target_tokens(group_name)
        if not parts:
            return False
        return all(p in candidate for p in parts)

    def _clear_search_box(self, search_box):
        try:
            search_box.click()
        except Exception:
            pass
        for _ in range(2):
            try:
                search_box.send_keys(Keys.CONTROL, 'a')
                search_box.send_keys(Keys.DELETE)
            except Exception:
                pass
            try:
                self.driver.execute_script("arguments[0].value = ''; arguments[0].dispatchEvent(new Event('input', {bubbles:true}));", search_box)
            except Exception:
                pass
            time.sleep(0.2)

    def _extract_header_title_text(self):
        candidates = [
            ".header-title",
            ".header-title span",
            "header .header-title",
            "header [class*='header-title']",
        ]
        for selector in candidates:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
            except Exception:
                elements = []
            for el in elements:
                try:
                    text = (el.text or "").strip()
                except Exception:
                    text = ""
                if text:
                    return text
        return ""

    def _verify_current_group_title(self, group_name, timeout=5):
        WebDriverWait(self.driver, timeout).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".header-title"))
        )
        header_text = self._extract_header_title_text()
        return self._matches_target_group(header_text, group_name), header_text

    def _wait_until_header_matches(self, group_name, timeout=6, stable_checks=2):
        """Chờ header đổi sang đúng target room và ổn định ngắn trong vài poll liên tiếp."""
        deadline = time.time() + max(0.5, float(timeout or 6))
        stable = 0
        last_header_text = ""
        while time.time() < deadline:
            matched, header_text = self._verify_current_group_title(group_name, timeout=1)
            last_header_text = header_text
            fallback_matched = False
            if not matched:
                normalized_header = self._strip_noise_tokens(header_text)
                normalized_target = self._strip_noise_tokens(group_name)
                fallback_matched = bool(
                    normalized_header and normalized_target and (
                        normalized_header in normalized_target or normalized_target in normalized_header
                    )
                )

            if matched or fallback_matched:
                stable += 1
                if stable >= max(1, int(stable_checks or 1)):
                    return True, header_text
            else:
                stable = 0
            time.sleep(0.2)
        return False, last_header_text

    def _warmup_room_after_open(self, scroll_rounds=1, settle_seconds=0.6):
        """Warmup nhẹ sau khi mở room để giảm render churn trong multi-room mode."""
        time.sleep(max(0.0, float(settle_seconds or 0.0)))
        for _ in range(max(0, int(scroll_rounds or 0))):
            self.driver.execute_script("""
                var chatContainer = document.querySelector('.chat-container, .conversation-list');
                if (chatContainer) {
                    chatContainer.scrollTop = 0;
                } else {
                    window.scrollTo(0, 0);
                }
            """)
            time.sleep(0.2)
            self.driver.execute_script("""
                var chatContainer = document.querySelector('.chat-container, .conversation-list');
                if (chatContainer) {
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                } else {
                    window.scrollTo(0, document.body.scrollHeight);
                }
            """)
            time.sleep(0.2)
    
    @retry_on_webdriver_error(max_retries=3)
    def open_zalo_web(self):
        """Mở trang Zalo Web và đợi tải xong"""
        try:
            self.driver.get("https://chat.zalo.me/")
            # Đợi cho trang tải xong
            WebDriverWait(self.driver, 20).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            log("Đã mở trang Zalo Web")
            return True
        except Exception as e:
            log(f"Lỗi khi mở Zalo Web: {str(e)}", level=logging.ERROR)
            return False
    
    @retry_on_webdriver_error(max_retries=2)
    def check_login_status(self):
        """Kiểm tra xem đã đăng nhập vào Zalo Web chưa.

        Giữ semantics đồng bộ với auth/login.py:
        - không nuốt nhầm lỗi browser chết/tab crash
        - phân biệt rõ logged-in / qr-visible / unknown-state trong log
        """
        try:
            WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.ID, "contact-search-input"))
            )
            log(f"Đã đăng nhập vào Zalo (reason={ALREADY_LOGGED_IN})")
            return True
        except TimeoutException:
            pass
        except Exception as e:
            if is_browser_dead_error(e):
                log(f"Lỗi browser khi kiểm tra trạng thái đăng nhập: {str(e)}", level=logging.WARNING)
                raise
            log(f"Không thấy marker đăng nhập, sẽ kiểm tra QR: {str(e)}", level=logging.WARNING)

        try:
            WebDriverWait(self.driver, 3).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, ".qrcode img"))
            )
            log(f"Chưa đăng nhập, cần quét mã QR (reason={QR_VISIBLE})")
            return False
        except Exception as e:
            if is_browser_dead_error(e):
                log(f"Lỗi browser khi kiểm tra QR đăng nhập: {str(e)}", level=logging.WARNING)
                raise
            self.capture_fail_artifact(phase="navigation.check_login_status", reason=LOGIN_STATE_UNKNOWN)
            log(f"Không thể xác định trạng thái đăng nhập (reason={LOGIN_STATE_UNKNOWN})", level=logging.WARNING)
            return False
    
    @retry_on_webdriver_error(max_retries=3)
    def find_and_access_group(self, group_name=None):
        """Tìm và truy cập nhóm chat Zalo; chỉ success khi verify đúng target room."""
        if not group_name:
            group_name = DEFAULT_GROUP_NAME

        try:
            matched_current, header_text = self._verify_current_group_title(group_name, timeout=1)
            if matched_current:
                log(f"Đã ở sẵn trong nhóm '{group_name}' (header='{header_text}')", level=logging.DEBUG)
                return True
        except Exception as precheck_error:
            if is_browser_dead_error(precheck_error):
                raise

        try:
            search_box = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.ID, "contact-search-input"))
            )
            self._clear_search_box(search_box)
            search_box.send_keys(group_name)
            time.sleep(1.2)

            conv_items = self.driver.find_elements(By.CSS_SELECTOR, ".conv-item")
            labels = self._collect_conv_item_labels(conv_items)
            log(f"Tìm thấy {len(conv_items)} kết quả tìm kiếm cho '{group_name}'; top_results={labels}")

            for item in conv_items:
                item_text = item.text
                if not item_text:
                    continue
                item_text_norm = item_text.strip()
                matched = self._matches_target_group(item_text_norm, group_name)

                if matched:
                    log(f"Tìm thấy nhóm phù hợp: '{item_text_norm}'")
                    self.driver.execute_script("arguments[0].scrollIntoView(true);", item)
                    time.sleep(0.35)
                    self.driver.execute_script("arguments[0].click();", item)
                    log(f"Đã click vào nhóm '{group_name}'")

                    try:
                        matched_header, header_text = self._wait_until_header_matches(group_name, timeout=6)
                        if not matched_header:
                            self.capture_fail_artifact(
                                phase="navigation.find_and_access_group.verify",
                                reason=GROUP_OPENED_UNVERIFIED,
                                group_name=group_name,
                                extra={"top_results": labels, "header_text": header_text, "clicked_item": item_text_norm},
                            )
                            log(
                                f"Click xong nhưng header vẫn chưa khớp '{group_name}'; header='{header_text}', clicked_item='{item_text_norm}'",
                                level=logging.WARNING,
                            )
                            return False

                        log(
                            f"Đã truy cập nhóm '{group_name}' thành công (reason={GROUP_OPENED_AT_NAVIGATION}; header='{header_text}')."
                        )
                        self._warmup_room_after_open(scroll_rounds=1, settle_seconds=0.6)
                        log(f"({group_name}) Tin nhắn đã load sẵn sàng để crawl", level=logging.DEBUG)
                        return True
                    except Exception as e:
                        if is_browser_dead_error(e):
                            level = logging.DEBUG if self._should_quiet_shutdown_browser_error(e) else logging.ERROR
                            log(f"Lỗi browser khi xác nhận nhóm: {str(e)}", level=level)
                            raise
                        self.capture_fail_artifact(
                            phase="navigation.find_and_access_group.verify",
                            reason=GROUP_OPENED_UNVERIFIED,
                            group_name=group_name,
                            extra={"top_results": labels, "clicked_item": item_text_norm},
                        )
                        log(f"Không thể xác nhận tiêu đề nhóm: {str(e)}", level=logging.WARNING)
                        return False

            self.capture_fail_artifact(
                phase="navigation.find_and_access_group.search",
                reason=GROUP_SEARCH_EMPTY,
                group_name=group_name,
                extra={"top_results": labels},
            )
            log(
                f"Không tìm thấy nhóm '{group_name}' trong kết quả tìm kiếm; reason={GROUP_SEARCH_EMPTY}; top_results={labels}",
                level=logging.ERROR,
            )
            return False
            
        except Exception as e:
            level = logging.DEBUG if self._should_quiet_shutdown_browser_error(e) else logging.ERROR
            log(f"Lỗi khi tìm kiếm nhóm: {str(e)}", level=level)
            if not self._should_quiet_shutdown_browser_error(e):
                ctx = {"group_name": group_name, "phase": "find_and_access_group"}
                try:
                    ctx["current_url"] = self.driver.current_url
                    ctx["page_title"] = self.driver.title
                except Exception:
                    pass
                log_error(e, context=ctx, extra_message="Lỗi khi tìm kiếm nhóm")
            if is_browser_dead_error(e):
                raise  # Để main loop có thể recover browser
            return False
    
    @retry_on_webdriver_error(max_retries=3)
    def reconnect_to_group(self, group_name=None):
        """Kết nối lại với nhóm chat sau khi làm mới trang; chỉ success khi verify đúng room."""
        if not group_name:
            group_name = DEFAULT_GROUP_NAME

        try:
            matched_current, header_text = self._verify_current_group_title(group_name, timeout=1)
            if matched_current:
                log(f"Reconnect bỏ qua search vì đã ở đúng room '{group_name}' (header='{header_text}')", level=logging.DEBUG)
                return True
        except Exception as precheck_error:
            if is_browser_dead_error(precheck_error):
                raise

        try:
            search_input = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.ID, "contact-search-input"))
            )
            self._clear_search_box(search_input)
            search_input.send_keys(group_name)
            time.sleep(1.0)

            conv_items = self.driver.find_elements(By.CSS_SELECTOR, ".conv-item")
            labels = self._collect_conv_item_labels(conv_items)
            log(f"Reconnect search cho '{group_name}'; top_results={labels}", level=logging.DEBUG)
            for item in conv_items:
                item_text = item.text
                if not item_text:
                    continue
                item_text_norm = item_text.strip()
                matched = self._matches_target_group(item_text_norm, group_name)

                if matched:
                    log(f"Tìm thấy nhóm phù hợp: '{item_text_norm}'")
                    self.driver.execute_script("arguments[0].scrollIntoView(true);", item)
                    time.sleep(0.35)
                    self.driver.execute_script("arguments[0].click();", item)
                    try:
                        matched_header, header_text = self._wait_until_header_matches(group_name, timeout=6)
                        if not matched_header:
                            self.capture_fail_artifact(
                                phase="navigation.reconnect_to_group.verify",
                                reason=RECONNECT_HEADER_UNVERIFIED,
                                group_name=group_name,
                                extra={"top_results": labels, "header_text": header_text, "clicked_item": item_text_norm},
                            )
                            log(
                                f"Reconnect click xong nhưng header vẫn chưa đổi sang '{group_name}'; header='{header_text}', clicked_item='{item_text_norm}'",
                                level=logging.WARNING,
                            )
                            return False
                        self._warmup_room_after_open(scroll_rounds=1, settle_seconds=0.5)
                        log(
                            f"Đã truy cập lại nhóm '{group_name}' ở navigation layer; reason={GROUP_OPENED_AT_NAVIGATION}; header='{header_text}'",
                            level=logging.INFO,
                        )
                    except Exception as verify_error:
                        if is_browser_dead_error(verify_error):
                            level = logging.DEBUG if self._should_quiet_shutdown_browser_error(verify_error) else logging.ERROR
                            log(f"Lỗi browser khi verify reconnect header: {str(verify_error)}", level=level)
                            raise
                        self.capture_fail_artifact(
                            phase="navigation.reconnect_to_group.verify",
                            reason=RECONNECT_HEADER_UNVERIFIED,
                            group_name=group_name,
                            extra={"top_results": labels, "clicked_item": item_text_norm},
                        )
                        log(
                            f"Reconnect click xong nhưng chưa verify được header cho '{group_name}': reason={RECONNECT_HEADER_UNVERIFIED}; {str(verify_error)}",
                            level=logging.WARNING,
                        )
                        return False
                    return True
            
            self.capture_fail_artifact(
                phase="navigation.reconnect_to_group.search",
                reason=GROUP_SEARCH_EMPTY,
                group_name=group_name,
                extra={"top_results": labels},
            )
            log(
                f"Không tìm thấy nhóm '{group_name}' trong kết quả tìm kiếm; reason={GROUP_SEARCH_EMPTY}; top_results={labels}",
                level=logging.ERROR,
            )
            return False
        except Exception as e:
            level = logging.DEBUG if self._should_quiet_shutdown_browser_error(e) else logging.ERROR
            log(f"Lỗi khi kết nối lại với nhóm: {str(e)}", level=level)
            return False